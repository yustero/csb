id files need to have a blank line at the end I think. until this is fixed. keep an eye out
